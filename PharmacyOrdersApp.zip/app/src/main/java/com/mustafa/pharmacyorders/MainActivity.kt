package com.mustafa.pharmacyorders

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ScaleGestureDetector
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    data class OrderItem(val name: String, val quantity: Int, val store: String)

    private val medicines = mutableListOf(
        "Panadol", "Augmentin", "Flagyl", "Glucophage",
        "Neurobin", "Mamacare", "Pregabalin", "Duphaston"
    )
    private val photos = mutableListOf<Uri>()
    private val order = mutableListOf<OrderItem>()
    private var photoIndex = 0
    private var medicineIndex = 0
    private var selectedStore = ""
    private var zoom = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        receivePhotos(intent)
        if (photos.isNotEmpty()) showOrderScreen() else showHome()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        receivePhotos(intent)
        showOrderScreen()
    }

    private fun receivePhotos(intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (uri != null) {
                    photos.clear()
                    photos.add(uri)
                    photoIndex = 0
                }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val list = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                if (!list.isNullOrEmpty()) {
                    photos.clear()
                    photos.addAll(list)
                    photoIndex = 0
                }
            }
        }
    }

    private fun showHome() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(30, 30, 30, 30)
        }
        box.addView(TextView(this).apply {
            text = "صيدليتي"
            textSize = 32f
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = "الطلبية اليومية"
            textSize = 20f
            gravity = Gravity.CENTER
        })
        box.addView(Button(this).apply {
            text = "هيا نبدأ"
            setOnClickListener { showOrderScreen() }
        })
        setContentView(box)
    }

    private fun showOrderScreen() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(20, 20, 20, 40)
        }
        val counter = TextView(this).apply { gravity = Gravity.CENTER }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }

        if (photos.isEmpty()) {
            counter.text = "لا توجد صور رفوف"
        } else {
            if (photoIndex > photos.lastIndex) photoIndex = 0
            counter.text = "صورة ${photoIndex + 1} من ${photos.size}"
            image.setImageURI(photos[photoIndex])
        }

        val detector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    zoom = (zoom * detector.scaleFactor).coerceIn(1f, 5f)
                    image.scaleX = zoom
                    image.scaleY = zoom
                    return true
                }
            }
        )
        image.setOnTouchListener { _, event ->
            detector.onTouchEvent(event)
            true
        }

        box.addView(counter)
        box.addView(
            image,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 700)
        )

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        nav.addView(Button(this).apply {
            text = "← السابقة"
            setOnClickListener {
                if (photos.isNotEmpty()) {
                    photoIndex = if (photoIndex == 0) photos.lastIndex else photoIndex - 1
                    zoom = 1f
                    showOrderScreen()
                }
            }
        })
        nav.addView(Button(this).apply {
            text = "التالية →"
            setOnClickListener {
                if (photos.isNotEmpty()) {
                    photoIndex = if (photoIndex == photos.lastIndex) 0 else photoIndex + 1
                    zoom = 1f
                    showOrderScreen()
                }
            }
        })
        box.addView(nav)

        box.addView(Button(this).apply {
            text = "📷 إضافة صور الرفوف"
            setOnClickListener {
                val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(picker, 100)
            }
        })

        if (medicineIndex < medicines.size) addMedicineControls(box) else addResult(box)
        scroll.addView(box)
        setContentView(scroll)
    }

    private fun addMedicineControls(box: LinearLayout) {
        box.addView(TextView(this).apply {
            text = "العلاج ${medicineIndex + 1} من ${medicines.size}"
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = medicines[medicineIndex]
            textSize = 28f
            gravity = Gravity.CENTER
        })
        val quantity = EditText(this).apply {
            hint = "اكتب الكمية"
            gravity = Gravity.CENTER
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        box.addView(quantity)

        val stores = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            gravity = Gravity.CENTER
        }
        stores.addView(RadioButton(this).apply {
            text = "Amazon"
            setOnClickListener { selectedStore = "Amazon" }
        })
        stores.addView(RadioButton(this).apply {
            text = "راية"
            setOnClickListener { selectedStore = "راية" }
        })
        box.addView(stores)

        box.addView(Button(this).apply {
            text = "حفظ والتالي"
            setOnClickListener {
                val qty = quantity.text.toString().toIntOrNull()
                if (qty == null || qty < 1) {
                    Toast.makeText(this@MainActivity, "اكتب الكمية", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (selectedStore.isEmpty()) {
                    Toast.makeText(this@MainActivity, "اختر Amazon أو راية", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                order.add(OrderItem(medicines[medicineIndex], qty, selectedStore))
                medicineIndex++
                selectedStore = ""
                showOrderScreen()
            }
        })
        box.addView(Button(this).apply {
            text = "تخطي"
            setOnClickListener {
                medicineIndex++
                selectedStore = ""
                showOrderScreen()
            }
        })
    }

    private fun addResult(box: LinearLayout) {
        val text = buildOrderText()
        box.addView(TextView(this).apply {
            this.text = "✅ الطلبية جاهزة\n\n$text"
            textSize = 18f
        })
        box.addView(Button(this).apply {
            text = "نسخ الطلبية"
            setOnClickListener {
                val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("الطلبية", text))
                Toast.makeText(this@MainActivity, "تم نسخ الطلبية", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply {
            text = "طلبية جديدة"
            setOnClickListener {
                medicineIndex = 0
                selectedStore = ""
                order.clear()
                showOrderScreen()
            }
        })
    }

    private fun buildOrderText(): String {
        val result = StringBuilder()
        val amazon = order.filter { it.store == "Amazon" }
        val raya = order.filter { it.store == "راية" }

        if (amazon.isNotEmpty()) {
            result.append("【 Amazon 】\n")
            amazon.forEach { result.append("${it.name} no ${it.quantity}\n") }
        }
        if (raya.isNotEmpty()) {
            if (result.isNotEmpty()) result.append("\n")
            result.append("【 راية 】\n")
            raya.forEach { result.append("${it.name} no ${it.quantity}\n") }
        }
        return if (result.isEmpty()) "لا توجد أصناف" else result.toString()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            photos.clear()
            val clip = data?.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    photos.add(clip.getItemAt(i).uri)
                }
            } else {
                data?.data?.let { photos.add(it) }
            }
            photoIndex = 0
            zoom = 1f
            showOrderScreen()
        }
    }
}
